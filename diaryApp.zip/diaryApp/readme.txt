diaryApp is devloped by Meraj Ahmad.
+91 - 8495806215

Note : 

1. Default controller is Login.
2. database Name is mydiaryapp
3. username is root without paasword.
4. table name is tododiary.
5. added db sql file into mydiaryapp\db folder
6. for both login User name and paasword is admin.
7. CI version is 3.1.8


